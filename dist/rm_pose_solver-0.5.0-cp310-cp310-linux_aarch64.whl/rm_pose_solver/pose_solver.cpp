#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>

#include <boost/math/tools/minima.hpp>

#include <Eigen/Dense>

#include <array>
#include <cmath>
#include <condition_variable>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <tuple>

namespace py = pybind11;

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

static constexpr double kYawTolRad   = 0.1 * (M_PI / 180.0);
static constexpr int    kBrentBits   = static_cast<int>(
    std::ceil(std::log2(M_PI / kYawTolRad))); // worst-case bits for [-π/2, π/2]

// ---------------------------------------------------------------------------
// Input bundle
// ---------------------------------------------------------------------------

struct SolveInputs {
    // 4 object points as columns: [p0 | p1 | p2 | p3], shape 3×4
    Eigen::Matrix<double, 3, 4> obj_pts;

    // Observed pixel coords, shape 2×4
    Eigen::Matrix<double, 2, 4> observed;

    // Camera intrinsics
    double fx, fy, cx, cy;

    // Translation vector
    Eigen::Vector3d t;

    // Fixed-angle trig (pitch, roll precomputed)
    double sin_pitch, cos_pitch, sin_roll, cos_roll;
};

// ---------------------------------------------------------------------------
// Unpack Python arrays into SolveInputs — runs once per solve call.
// ---------------------------------------------------------------------------

static SolveInputs unpack_inputs(
    py::array_t<double> image_points,
    py::array_t<double> position_xyz,
    py::array_t<double> plate_matrix,
    py::array_t<double> camera_matrix,
    double fixed_pitch,
    double fixed_roll)
{
    auto ip  = image_points.unchecked<2>();   // (4,2)
    auto pos = position_xyz.unchecked<1>();   // (3,)
    auto pm  = plate_matrix.unchecked<2>();   // (4,3)
    auto km  = camera_matrix.unchecked<2>();  // (3,3)

    if (ip.shape(0) != 4 || ip.shape(1) != 2)
        throw std::invalid_argument("image_points must be shape (4, 2)");
    if (pos.shape(0) != 3)
        throw std::invalid_argument("position_xyz must be shape (3,)");
    if (pm.shape(0) != 4 || pm.shape(1) != 3)
        throw std::invalid_argument("plate_matrix must be shape (4, 3)");
    if (km.shape(0) != 3 || km.shape(1) != 3)
        throw std::invalid_argument("camera_matrix must be shape (3, 3)");

    SolveInputs inp{};

    for (int i = 0; i < 4; ++i) {
        inp.observed(0, i) = ip(i, 0);
        inp.observed(1, i) = ip(i, 1);
        inp.obj_pts(0, i)  = pm(i, 0);
        inp.obj_pts(1, i)  = pm(i, 1);
        inp.obj_pts(2, i)  = pm(i, 2);
    }

    inp.t = { pos(0), pos(1), pos(2) };

    inp.fx = km(0, 0); inp.fy = km(1, 1);
    inp.cx = km(0, 2); inp.cy = km(1, 2);

    inp.sin_pitch = std::sin(fixed_pitch); inp.cos_pitch = std::cos(fixed_pitch);
    inp.sin_roll  = std::sin(fixed_roll);  inp.cos_roll  = std::cos(fixed_roll);

    return inp;
}

// ---------------------------------------------------------------------------
// Build ZYX rotation matrix R = Rz(yaw) * Ry(pitch) * Rx(roll).
// Only yaw varies per call; pitch/roll trig are precomputed in SolveInputs.
// ---------------------------------------------------------------------------

static inline Eigen::Matrix3d build_rotation(
    const SolveInputs& inp, double yaw) noexcept
{
    const double cy = std::cos(yaw), sy = std::sin(yaw);
    const double cp = inp.cos_pitch,  sp = inp.sin_pitch;
    const double cr = inp.cos_roll,   sr = inp.sin_roll;

    Eigen::Matrix3d R;
    R << cy*cp,          cy*sp*sr - sy*cr,  cy*sp*cr + sy*sr,
         sy*cp,          sy*sp*sr + cy*cr,  sy*sp*cr - cy*sr,
        -sp,             cp*sr,             cp*cr;
    return R;
}

// ---------------------------------------------------------------------------
// Cost: squared reprojection error over all 4 points.
//
// Camera convention: X=forward (depth), Y=left, Z=up.
// Projection: u = fx * (-Y/X) + cx,  v = fy * (-Z/X) + cy
//
// Using Eigen here gives us:
//   - vectorised column-wise operations (NEON on Jetson)
//   - clean expression without index arithmetic
//   - compile-time sizes enable full unrolling
// ---------------------------------------------------------------------------

static inline double squared_reprojection_error(
    const SolveInputs& inp, double yaw) noexcept
{
    // Transform all 4 points at once: cam_pts = R * obj_pts + t (broadcast)
    const Eigen::Matrix<double, 3, 4> cam =
        build_rotation(inp, yaw) * inp.obj_pts + inp.t.replicate<1, 4>();

    // Perspective divide — cam.row(0) is X (depth)
    const Eigen::Array<double, 1, 4> inv_X = cam.row(0).array().inverse();

    const Eigen::Array<double, 1, 4> u =
        inp.fx * (-cam.row(1).array() * inv_X) + inp.cx;
    const Eigen::Array<double, 1, 4> v =
        inp.fy * (-cam.row(2).array() * inv_X) + inp.cy;

    const Eigen::Array<double, 1, 4> du = u - inp.observed.row(0).array();
    const Eigen::Array<double, 1, 4> dv = v - inp.observed.row(1).array();

    return (du * du + dv * dv).sum();
}

// ---------------------------------------------------------------------------
// Persistent two-thread pool for parallel Brent searches.
// Created once on first solve call via a local static.
// ---------------------------------------------------------------------------

class BrentPool {
public:
    BrentPool() {
        for (int id = 0; id < 2; ++id) {
            workers_[id] = std::thread([this, id] { worker_loop(id); });
        }
    }

    ~BrentPool() {
        shutdown_ = true;
        for (int id = 0; id < 2; ++id) {
            cv_[id].notify_one();
            workers_[id].join();
        }
    }

    // Returns {yaw, cost} for each half.
    std::array<std::pair<double, double>, 2> run(
        const SolveInputs& inp,
        double lo, double mid, double hi)
    {
        bounds_[0] = {lo,  mid};
        bounds_[1] = {mid, hi};

        for (int id = 0; id < 2; ++id) {
            std::lock_guard lk(mtx_[id]);
            inputs_[id] = &inp;
            done_[id]   = false;
            ready_[id]  = true;
        }
        cv_[0].notify_one();
        cv_[1].notify_one();

        for (int id = 0; id < 2; ++id) {
            std::unique_lock lk(mtx_[id]);
            cv_[id].wait(lk, [&] { return done_[id]; });
        }

        return {results_[0], results_[1]};
    }

private:
    void worker_loop(int id) {
        while (true) {
            std::unique_lock lk(mtx_[id]);
            cv_[id].wait(lk, [&] { return ready_[id] || shutdown_; });
            if (shutdown_) return;

            boost::uintmax_t max_iter = 200;
            results_[id] = boost::math::tools::brent_find_minima(
                [&](double y) {
                    return squared_reprojection_error(*inputs_[id], y);
                },
                bounds_[id].first, bounds_[id].second,
                kBrentBits, max_iter);

            ready_[id] = false;
            done_[id]  = true;
            lk.unlock();
            cv_[id].notify_one();
        }
    }

    std::array<std::thread, 2>              workers_;
    std::array<std::mutex, 2>               mtx_;
    std::array<std::condition_variable, 2>  cv_;
    std::array<const SolveInputs*, 2>       inputs_{};
    std::array<std::pair<double, double>, 2> bounds_{};
    std::array<std::pair<double, double>, 2> results_{};
    std::array<bool, 2>                     ready_   = {false, false};
    std::array<bool, 2>                     done_    = {false, false};
    bool                                    shutdown_ = false;
};

// ---------------------------------------------------------------------------
// solve_yaw — public entry point
// ---------------------------------------------------------------------------

/**
 * Minimize plate keypoint reprojection error over yaw using Brent's method.
 * The search range is split at its midpoint and searched in parallel across
 * two threads, covering both basins of a W-shaped cost surface.
 * Images must be pre-undistorted; no distortion coefficients are accepted.
 *
 * Args:
 *   image_points  (4,2) float64 — observed pixel keypoints [BL,BR,TR,TL]
 *   position_xyz  (3,)  float64 — tvec in camera frame (metres)
 *   plate_matrix  (4,3) float64 — 3-D plate corner object points
 *   camera_matrix (3,3) float64 — intrinsic K (fx,fy,cx,cy only used)
 *   fixed_pitch   float — pitch in radians
 *   fixed_roll    float — roll in radians
 *   yaw_lo        float — search lower bound (default -π/2)
 *   yaw_hi        float — search upper bound (default +π/2)
 *
 * Returns:
 *   (yaw1, rms1, yaw2, rms2): best yaw and per-point RMS from each half
 */
static std::tuple<double, double, double, double> solve_yaw(
    py::array_t<double> image_points,
    py::array_t<double> position_xyz,
    py::array_t<double> plate_matrix,
    py::array_t<double> camera_matrix,
    double fixed_pitch,
    double fixed_roll,
    double yaw_lo,
    double yaw_hi)
{
    if (!std::isfinite(yaw_lo) || !std::isfinite(yaw_hi))
        throw std::invalid_argument("yaw bounds must be finite");
    if (yaw_hi < yaw_lo)
        throw std::invalid_argument("yaw_hi must be >= yaw_lo");

    const SolveInputs inputs = unpack_inputs(
        image_points, position_xyz, plate_matrix, camera_matrix,
        fixed_pitch, fixed_roll);

    const double mid = 0.5 * (yaw_lo + yaw_hi);

    // Lazy-init pool — avoids global destructor ordering issues.
    static BrentPool pool;

    std::array<std::pair<double, double>, 2> res;
    {
        py::gil_scoped_release release;
        res = pool.run(inputs, yaw_lo, mid, yaw_hi);
    }

    return {
        res[0].first, std::sqrt(0.25 * res[0].second),
        res[1].first, std::sqrt(0.25 * res[1].second)
    };
}

// ---------------------------------------------------------------------------
// Module definition
// ---------------------------------------------------------------------------

PYBIND11_MODULE(_rm_pose_solver, m)
{
    m.doc() = "RoboMaster pose solver — dual Brent minimization via Boost.Math + Eigen";

    m.def("solve_yaw", &solve_yaw,
        py::arg("image_points"),
        py::arg("position_xyz"),
        py::arg("plate_matrix"),
        py::arg("camera_matrix"),
        py::arg("fixed_pitch"),
        py::arg("fixed_roll"),
        py::arg("yaw_lo") = -M_PI / 2.0,
        py::arg("yaw_hi") =  M_PI / 2.0);
}